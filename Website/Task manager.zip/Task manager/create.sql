CREATE TABLE IF NOT EXISTS Tasks(
tastID INTEGER PRIMARY KEY,
task TEXT NOT NULL, 
describe TEXT,
due_date INTEGER,
completed INTEGER,
weather INTEGER
)