import sqlite3
from datetime import datetime, timedelta,date
import requests, json
from tkinter import *
from tkinter import ttk

def runSQL(sql):

    connection = sqlite3.connect('task.db')
    cursor = connection.cursor()

    result_set = cursor.execute(sql)

    cursor.close()
    connection.close()

def create_task(name,describe,due_date,weather):
    name = str(name)
    describe = str(describe)
    due_date = str(due_date)
    completed = str(0)
    if weather == True:
        weather = str(1)
    else:
        weather = str(0)
    
    connection = sqlite3.connect('task.db')
    cursor = connection.cursor()
    sqlite_insert_with_param = """INSERT INTO Tasks
                          (task ,describe, due_date, completed, weather) 
                          VALUES (?, ?, ?, ?, ?);"""

    data_tuple = (name, describe, due_date, completed, weather)
    cursor.execute(sqlite_insert_with_param, data_tuple)
    connection.commit()
    
    cursor.close()
    connection.close()

def getTasks():

    connection1 = sqlite3.connect('task.db')
    cursor1 = connection1.cursor()
    
    result_set = cursor1.execute("SELECT * FROM Tasks;")
    for row in result_set:
        print(row)
        
    cursor1.close()
    connection1.close()

def deleteTask(TK):
    TK= int(TK)
    connection2 = sqlite3.connect('task.db')
    cursor2 = connection2.cursor()

    sql_update_query = """DELETE from Tasks where tastID = ?"""
    cursor2.execute(sql_update_query, (TK,))
    connection2.commit()

    
    cursor2.close()
    connection2.close()
    
def updateTask(to_set, set_to, tid):
    connection3 = sqlite3.connect('task.db')
    cursor3 = connection3.cursor()
    if to_set == "task":
        sql_update_query = """Update Tasks set task = ? where tastID = ?"""
    elif to_set == "describe":
        sql_update_query = """Update Tasks set describe = ? where tastID = ?"""
    elif to_set == "due_date":
        sql_update_query = """Update Tasks set due_date = ? where tastID = ?"""
    elif to_set == "ID":
        sql_update_query = """Update Tasks set tastID = ? where tastID = ?"""
    elif to_set == "completed":
        if set_to == "True":
            set_to = str(1)
        else:
            set_to = str(0)
        sql_update_query = """Update Tasks set completed = ? where tastID = ?"""
    elif to_set == "weather":
        if set_to == "True":
            set_to = str(1)
        else:
            set_to = str(0)
        sql_update_query = """Update Tasks set weather = ? where tastID = ?"""
    
    data = (set_to, tid)
    cursor3.execute(sql_update_query, data)
    connection3.commit()
    cursor3.close()
    connection3.close()
    
    
def is_integer(n):
    try:
        float(n)
    except ValueError:
        return False
    else:
        return float(n).is_integer()
    
def reminder():
    present = date.today()

    connection4 = sqlite3.connect('task.db')
    cursor4 = connection4.cursor()
    
    result_set = cursor4.execute("SELECT * FROM Tasks;")
    x = 0
    for row in result_set:
        x = x+1
    for i in range(x):
        sql_update_query = ("SELECT due_date FROM Tasks WHERE tastID = ?;")
        dates = cursor4.execute(sql_update_query,  (x,))
        for dae in dates:
            dae =  str(dae)
            day = dae[1:2]
            if len(dae) < 11:
                day = "0"  + (dae[1:2])
                month = (dae[2:4])
                year = int(dae[4:8])
            else:
                day =  (dae[1:3])
                month = (dae[3:5])
                year = int(dae[5:9])         
            da = date(int(year), int(month) , int(day))
            difference = diff_dates(da, present)
            if difference < 5:
                print ("Upcoming task. ID:" + str(x))
        x = x+1
        
    cursor4.close()
    connection4.close()
    
def diff_dates(date1, date2):
    return abs(date2-date1).days

def wether():
# Enter your API key here
    api_key = "455100bc42d0d69e541ff007209f6654"
    
    # base_url variable to store url
    base_url = "http://api.openweathermap.org/data/2.5/weather?"
    
    # Give city name
    city_name = "Brighton,uk"
    
    # complete_url variable to store
    # complete url address
    complete_url= base_url + "q=" + city_name + "&APPID=" + api_key
    # get method of requests module
    # return response object
    response = requests.get(complete_url)
    
    # json method of response object
    # convert json format data into
    # python format data
    x = response.json()
    
    # Now x contains list of nested dictionaries
    # Check the value of "cod" key is equal to
    # "404", means city is found otherwise,
    # city is not found
    if x["cod"] != "404":
    
        # store the value of "main"
        # key in variable y
        y = x["main"]
    
        # store the value corresponding
        # to the "temp" key of y
        current_temperature = y["temp"]
    
        # store the value corresponding
        # to the "pressure" key of y
        current_pressure = y["pressure"]
    
        # store the value corresponding
        # to the "humidity" key of y
        current_humidity = y["humidity"]
    
        # store the value of "weather"
        # key in variable z
        z = x["weather"]
    
        # store the value corresponding
        # to the "description" key at
        # the 0th index of z
        weather_description = z[0]["description"]
    
        # print following values
        print(" Temperature (in kelvin unit) = " +
                        str(current_temperature) +
            "\n atmospheric pressure (in hPa unit) = " +
                        str(current_pressure) +
            "\n humidity (in percentage) = " +
                        str(current_humidity) +
            "\n description = " +
                        str(weather_description))
    
    else:
        print(" City Not Found ")
        
def mainloop():
    loop = True
    while loop == True:
        print("----------Task Manager 1.0----------")
        reminder()
        task = input("What would you like to do?\n1. Create a new task\n2. View all tasks\n3. Delete a task\n4. Update a task\n5. Close\n")
        if task == "1":
            sub_loop = True
            while sub_loop == True:
                name = input("Enter the task name\n")
                sub_loop = False
            sub_loop = True
            while sub_loop == True:
                desc = input("Enter the task descriprtion\n")
                sub_loop = False
            sub_loop = True
            while sub_loop == True:
                due = input("Enter the task due date in format ddmmyyyy(enter 0 for no due date)\n")
                if len(due) == 8 and is_integer(due):
                    sub_loop = False
                else:
                    print("please enter a a number in format ddmmyyyy\n")
                    print (len(due))
            sub_loop = True
            while sub_loop == True:
                    weather = input("is the task weather dependent(enter True or False)\n")
                    if weather == "True" or weather == "False":
                        create_task(name,desc, due, weather)
                        sub_loop = False
                    else:
                        print("Please enter True OR False\n")

        elif task == "2":
            getTasks()
        elif task == "3":
            sub_loop = True
            while sub_loop == True:
                TK = input("Enter the ID of the task to be deleted\n")
                if is_integer(TK):
                    sub_loop = False
                else:
                    print("Please enter a valid number")           
            deleteTask(TK)
        elif task == "4":
            sub_loop = True
            while sub_loop == True:
                to_set = input("What do you want to change?\n")
                if to_set == "task" or to_set == "describe" or to_set == "due_date" or to_set == "completed" or to_set == "weather":
                    sub_loop = False
                else:
                    print("Please enter either task,describe,due_date,completed,weather")
            set_to = input("What should it be changed to\n")
            sub_loop = True
            while sub_loop == True:
                if to_set == "weather" or to_set =="completed":
                    if set_to == "True" or set_to == "False":
                        sub_loop = False
                    else:
                        print("Please enter True OR False for completed and weather\n")
                else:
                    sub_loop = False
            sub_loop = True
            while sub_loop == True:
                tid = input("What is the id of the task to be changed\n")
                if is_integer(tid):
                    sub_loop = False
                else:
                    print("Please enter a valid number")
            updateTask(to_set,set_to,tid)
        elif task == "5":
            loop = False
        else:
            print("Enter a valid number")
        
class popupWindowU(object):
    def __init__(self,master):
        top=self.top=Toplevel(master)
        self.l=Label(top,text="What entry do you want to edit?")
        self.l.pack()
        self.ete=Entry(top)
        self.ete.pack()
        self.l=Label(top,text="What should it be changed to?")
        self.l.pack()
        self.eet=Entry(top)
        self.eet.pack()
        self.l=Label(top,text="Enter the ID of the task to be changed")
        self.l.pack()
        self.ei=Entry(top)
        self.ei.pack()
        self.b=Button(top,text='Ok',command=self.cleanup)
        self.b.pack()
    def cleanup(self):
        self.valuete=self.ete.get()
        self.valueet=self.eet.get()
        self.valueiu=self.ei.get()
        self.top.destroy()

class popupWindowA(object):
    def __init__(self,master):
        top=self.top=Toplevel(master)
        self.l=Label(top,text="Enter the name of the task")
        self.l.pack()
        self.en=Entry(top)
        self.en.pack()
        self.l=Label(top,text="Enter the task description")
        self.l.pack()
        self.ed=Entry(top)
        self.ed.pack()
        self.l=Label(top,text="Enter the due date of the task")
        self.l.pack()
        self.edd=Entry(top)
        self.edd.pack()
        self.l=Label(top,text="Is the task weather dependent?")
        self.l.pack()
        self.ew=Entry(top)
        self.ew.pack()
        self.b=Button(top,text='Ok',command=self.cleanup)
        self.b.pack()
    def cleanup(self):
        sub_loop = True      
        while sub_loop == True:
            if len(self.en.get()) != 0:
                sub_loop = False
            else:
                popupWindowExtra(root, "The task name cannot be left blank")
                self.master.wait_window(self.w.top)
        self.valuena=self.en.get()
        self.valueda=self.ed.get()
        self.valuedda=self.edd.get()
        self.valuewa=self.ew.get()
        self.top.destroy()
        
class popupWindowD(object):
    def __init__(self,master):
        top=self.top=Toplevel(master)
        self.l=Label(top,text="Enter the ID of the task to be deleted")
        self.l.pack()
        self.ei=Entry(top)
        self.ei.pack()
        self.b=Button(top,text='Ok',command=self.cleanup)
        self.b.pack()
    def cleanup(self):
        self.valueid=self.ei.get()
        self.top.destroy()
        
class popupWindowExtra(object,):
    def __init__(self,master,text):
        top=self.top=Toplevel(master)
        self.l=Label(top,text=text)
        self.l.pack()
        self.b=Button(top,text='Ok',command=self.cleanup)
        self.b.pack()
    def cleanup(self):
        self.top.destroy()

class mainWindow(object):
    def __init__(self,master):
        self.master=master
        self.remind()
        global list_items
        list_items = []
        wether = "Brighton, UK: " + self.wether("Brighton,uk")
        controlFrame = Frame(master)
        root.grid_rowconfigure(0, weight=1)
        root.grid_columnconfigure(2,weight=1)
        controlFrame.rowconfigure(0,weight=1)
        controlFrame.rowconfigure(1,weight=1)
        self.Lb1 = Listbox(
            master,
            width = 50,
        )
        self.getitems()
        scrollbar = ttk.Scrollbar(
            root,
            orient=VERTICAL,
            command=self.Lb1.yview
        )
        controlFrame.grid(column=2,row=0,sticky=(N,E,S))
        self.Lb1['yscrollcommand'] = scrollbar.set

        scrollbar.grid(column=1, row=0, sticky=(N,S))
        self.Lb1.grid(column=0, row=0 ,sticky=(N,S))
        self.bA=Button(controlFrame,text="Add Task",command=self.popupA)
        self.bA.grid(column=0, row=5,sticky=E)
        self.bU=Button(controlFrame,text="Update Task",command=self.popupU)
        self.bU.grid(column=0, row=6,sticky=E)
        self.bD=Button(controlFrame,text="Delete Task",command=self.popupD)
        self.bD.grid(column=0, row=7,sticky=E)
        self.bC=Button(controlFrame,text="Close",command=root.destroy)
        self.bC.grid(column=0, row=0,sticky=(N,E))
        self.lw=Label(controlFrame,text=wether)
        self.lw.grid(column=0, row=1,sticky=(N,E))

    def remind(self):
            present = date.today()

            connection4 = sqlite3.connect('task.db')
            cursor4 = connection4.cursor()
            
            result_set = cursor4.execute("SELECT * FROM Tasks;")
            x = 0
            for row in result_set:
                x = x+1
            for i in range(x):
                sql_update_query = ("SELECT due_date FROM Tasks WHERE tastID = ?;")
                dates = cursor4.execute(sql_update_query,  (i + 1,))
                for dae in dates:
                    dae =  str(dae)
                    day = dae[1:2]
                    if len(dae) < 11:
                        day = "0"  + (dae[1:2])
                        month = (dae[2:4])
                        year = int(dae[4:8])
                    else:
                        day =  (dae[1:3])
                        month = (dae[3:5])
                        year = int(dae[5:9])         
                    da = date(int(year), int(month) , int(day))
                    difference = diff_dates(da, present)
                    if difference < 5:
                        popupWindowExtra(self.master, "Task due ID: " + str(i + 1))             
            cursor4.close()
            connection4.close()

    def wether(self,city):
        api_key = "455100bc42d0d69e541ff007209f6654"
        base_url = "http://api.openweathermap.org/data/2.5/weather?"
        city_name = city
        complete_url= base_url + "q=" + city_name + "&APPID=" + api_key
        response = requests.get(complete_url)
        x = response.json()
        if x["cod"] != "404":
            y = x["main"]
            z = x["weather"]

            weather_description = z[0]["description"]
            return weather_description
        
        else:
            print(" City Not Found ")



    def getitems(self):
        self.Lb1.delete(0,END)
        list_items.clear()
        connection1 = sqlite3.connect('task.db')
        cursor1 = connection1.cursor()
    
        result_set = cursor1.execute("SELECT * FROM Tasks;")
        for row in result_set:
            list_items.append(row)
        
        for i in range(len(list_items)):
            self.Lb1.insert(i, list_items[i])
        cursor1.close()
        connection1.close()
    def popupA(self):
        self.w=popupWindowA(self.master)
        self.bA["state"] = "disabled" 
        self.bU["state"] = "disabled" 
        self.bD["state"] = "disabled" 
        self.master.wait_window(self.w.top)
        self.bA["state"] = "normal"
        self.bU["state"] = "normal"
        self.bD["state"] = "normal"
        name, description, due_date, weather = self.entryValuea()
        sub_loop = True
        while sub_loop == True:
            if len(due_date) == 8 and is_integer(due_date):
                sub_loop = False
            else:
                popupWindowExtra(self.master,"please enter a a number in format ddmmyyyy#")
                self.master.wait_window(self.w.top)
        sub_loop = True
        while sub_loop == True:
            if weather == "True" or weather == "False":
                create_task(name,description, due_date, weather)
                sub_loop = False
            else:
                popupWindowExtra(self.master, "Please enter True OR False")
                self.master.wait_window(self.w.top)
        self.getitems()
        
    def popupU(self):
        self.w=popupWindowU(self.master)
        self.bA["state"] = "disabled" 
        self.bU["state"] = "disabled" 
        self.bD["state"] = "disabled" 
        self.master.wait_window(self.w.top)
        self.bA["state"] = "normal"
        self.bU["state"] = "normal"
        self.bD["state"] = "normal"
        sub_loop = True
        to_set, set_to, tid = self.entryValueu()
        while sub_loop == True:
            if to_set == "task" or to_set == "describe" or to_set == "due_date" or to_set == "completed" or to_set == "weather" or to_set == "ID":
                sub_loop = False
            else:
                popupWindowExtra(self.master,"Please enter either task,describe,due_date,completed,weather,ID")
        sub_loop = True
        while sub_loop == True:
            if to_set == "weather" or to_set =="completed":
                if set_to == "True" or set_to == "False":
                    sub_loop = False
                else:
                    popupWindowExtra(self.master,"Please enter True OR False for completed and weather\n")  
            else:
                sub_loop = False
        sub_loop = True
        while sub_loop == True:
            if is_integer(tid):
                sub_loop = False
            else:
                popupWindowExtra(self.master,"Please enter a valid number")
        updateTask(to_set,set_to,tid)
        self.getitems()
        
    def popupD(self):
        self.w=popupWindowD(self.master)
        self.bA["state"] = "disabled" 
        self.bU["state"] = "disabled" 
        self.bD["state"] = "disabled" 
        self.master.wait_window(self.w.top)
        self.bA["state"] = "normal"
        self.bU["state"] = "normal"
        self.bD["state"] = "normal"
        tidd = self.entryValued()
        sub_loop = True
        while sub_loop == True:
            if is_integer(tidd):
                sub_loop = False
            else:
                print("Please enter a valid number")           
        deleteTask(tidd)
        self.getitems()

    def entryValuea(self):
        return self.w.valuena, self.w.valueda, self.w.valuedda, self.w.valuewa        

    
    def entryValueu(self):
        return self.w.valuete, self.w.valueet, self.w.valueiu  
    
    def entryValued(self):
        return self.w.valueid  
root=Tk()
m=mainWindow(root)
root.mainloop()
