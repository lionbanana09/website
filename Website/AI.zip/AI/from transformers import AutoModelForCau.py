from transformers import AutoModelForCausalLM, AutoTokenizer
import torch


#change medium to small/large/medium
model_name = "microsoft/DialoGPT-medium"

tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)

nickname = input('Your nickname: ')
print('nchat (ask a question to start a conversation): ')

for respose_num in range(1000):
    
    question = input('{}: '.format(nickname))
    user_input = tokenizer.encode(question + tokenizer.eos_token, return_tensors="pt")
    chatbot_input = torch.cat([chat_history, user_input], dim=-1) if respose_num > 0 else user_input
    
    chat_history = model.generate(
        chatbot_input,
        do_sample=True,
        top_k=70,
        temperature=0.95,
        max_length=1000,
        pad_token_id=tokenizer.eos_token_id,
    )
    
    chat = tokenizer.decode(chat_history[:, chatbot_input.shape[-1]:][0], skip_special_tokens=True)
    
    print(f"Bot: {chat}")